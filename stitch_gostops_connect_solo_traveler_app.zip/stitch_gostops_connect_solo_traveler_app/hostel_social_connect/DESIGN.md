---
name: Hostel Social Connect
colors:
  surface: '#f8f9ff'
  surface-dim: '#d8dae0'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3f9'
  surface-container: '#eceef4'
  surface-container-high: '#e6e8ee'
  surface-container-highest: '#e0e2e8'
  on-surface: '#191c20'
  on-surface-variant: '#5c4037'
  inverse-surface: '#2d3135'
  inverse-on-surface: '#eff0f7'
  outline: '#907065'
  outline-variant: '#e5beb2'
  surface-tint: '#aa3600'
  primary: '#a63500'
  on-primary: '#ffffff'
  primary-container: '#d04400'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb59c'
  secondary: '#5d5e61'
  on-secondary: '#ffffff'
  secondary-container: '#e2e2e5'
  on-secondary-container: '#636467'
  tertiary: '#005ea3'
  on-tertiary: '#ffffff'
  tertiary-container: '#0077cd'
  on-tertiary-container: '#fdfcff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbcf'
  primary-fixed-dim: '#ffb59c'
  on-primary-fixed: '#390c00'
  on-primary-fixed-variant: '#822700'
  secondary-fixed: '#e2e2e5'
  secondary-fixed-dim: '#c6c6c9'
  on-secondary-fixed: '#1a1c1e'
  on-secondary-fixed-variant: '#454749'
  tertiary-fixed: '#d2e4ff'
  tertiary-fixed-dim: '#a1c9ff'
  on-tertiary-fixed: '#001c37'
  on-tertiary-fixed-variant: '#004880'
  background: '#f8f9ff'
  on-background: '#191c20'
  surface-variant: '#e0e2e8'
typography:
  display:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: -0.02em
  display-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '800'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 26px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.02em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system is engineered specifically for solo travellers breaking the ice in a shared physical hostel lounge. The atmosphere is vibrant, warm, open, and utterly practical. It trades unnecessary ornamentation, complex visual effects, and decorative distractions for immediate legibility, high tactile certainty, and an inviting, social energy.

Key principles:
- **Zero Decorative Clutter:** The interface acts as a physical-world catalyst, prioritizing fast discovery, local activity grouping, and simple face-to-face connections rather than retaining user attention on the screen.
- **Friendly Utilitarianism:** High tactile affordances with oversized hit-targets designed for relaxed one-handed mobile usage across couches, communal dining tables, or bunk spaces.
- **Warm Contrast:** Crisp white foundations paired with a single punchy hostel-branded orange accent to focus intentional actions and indicate presence.

## Colors

The palette is strictly constrained to prevent visual noise while maximizing legibility in changing ambient lighting conditions (bright sunlit rooftops to dim lounge areas).

- **Primary Accent (`#FF5500`):** The signature vibrant hostel orange. Used exclusively for focal interactive calls to action, active tab highlights, instant status badges, and join intents. It is never used for lengthy background fills or decorative framing.
- **Primary Text (`#1E2022`):** Deep charcoal black. Used for all primary headlines, user names, card titles, and high-emphasis states.
- **Secondary / Supporting Text (`#4A4D52`):** Grounded slate grey. Used for body descriptions, timestamps, metadata, and supporting labels to maintain readable contrast without overpowering the visual hierarchy.
- **Canvas & Card Base (`#FFFFFF` & `#FAFAFA`):** Pure white serves as the foreground surface for cards and sheets, resting over an ultra-clean `#FAFAFA` global background foundation.
- **Structural Dividers (`#E5E7EB`):** A soft, neutral grey border applied to containers, cards, and input fields to construct crisp division without shadows.

## Typography

Typography relies entirely on **Plus Jakarta Sans** for its approachable geometry, large x-height, and generous counters. This provides effortless scanning when glancing down at a device while mingling.

- **Weight Disciplines:** Restrict usage to `400` (body copy), `600` (interactive labels and section headers), `700` (card headlines and metadata pills), and `800` (page titles and welcome markers).
- **Line Heights:** Generously set between 1.25x and 1.5x to preserve open space within tight card containers.
- **Letter Spacing:** Subtle negative tracking (`-0.01em` to `-0.02em`) on sizes above 20px anchors display elements; slight positive tracking (`+0.02em`) is reserved exclusively for micro-labels (`label-sm`).

## Layout & Spacing

A mobile-first fluid layout with a maximum container boundary of `480px` for mobile app simulations, scaling to a central max-width of `768px` when viewed on tablets or desktop browsers.

- **Mobile Viewport Grid:** 4-column layout with `1rem` margins and `1rem` gutters. Edge-to-edge breathing room ensures primary interactions are easily triggered within thumb reach.
- **Rhythm & Padding:** Component spacing adheres to a strict 4px/8px incremental base rhythm. Vertical content groupings utilize `space-md` (`1rem`) internally, with section-level separations using `space-xl` (`2rem`).
- **One-Handed Zone:** Persistent bottom action bars and floating trigger areas sit safe-padded at `space-md` above the system navigation bar, ensuring frictionless solo-travel interaction.

## Elevation & Depth

This design system is completely free of drop shadows, ambient blur halos, and multi-layered elevation tiers. Visual separation and layering are achieved strictly through structural delineation:

- **Flat Surface Separation:** Structural cards and modal sheets use a pure `#FFFFFF` fill resting cleanly on the `#FAFAFA` base background.
- **Crisp Structural Borders:** Containers, divider rules, and cards are outlined by a uniform `1px solid #E5E7EB` border.
- **Zero Blurs / No Glassmorphism:** Backdrop filters and translucency are avoided to preserve raw contrast, maximize battery efficiency on mobile travel devices, and eliminate visual murkiness.
- **State Feedback:** Press states and active container states are communicated via a border color transition to `#FF5500` or a solid background fill shift, never through elevated drop shadows.

## Shapes

The shape system expresses casual friendliness and modern softness through generous pill and rounded geometries:

- **Buttons & Interactive CTAs:** Completely pill-shaped (`border-radius: 9999px`) to invite immediate touch.
- **Content Cards & Modals:** Built with `rounded-xl` (`1.5rem` / `24px`) to provide an organic, comfortable silhouette that contrasts with strict grid borders.
- **Chips & Badges:** Fully rounded pill shapes (`border-radius: 9999px`) for interest tags, hostel room designations, and traveler badges.
- **Text Inputs:** Soft, modern rounded forms matching `rounded-lg` (`1rem` / `16px`) for clean thumb interaction.

## Components

### Buttons
- **Primary Button:** Minimum height of `48px` (ideally `52px` on mobile screens). Solid `#FF5500` fill, white `#FFFFFF` label text in `label-lg` (`Plus Jakarta Sans`, 600 weight), pill-shaped (`rounded-full`), zero elevation. Active state shifts slightly to `#E8511E`.
- **Secondary / Ghost Button:** Minimum height of `48px`, background of transparent or `#FFFFFF`, `1px solid #E5E7EB` border, text `#1E2022`. On press or hover, border updates to `#1E2022`.
- **Icon Action Button:** `48px x 48px` square or circular touch target, `#FAFAFA` background, `#1E2022` icon stroke, pill-shaped.

### Cards
- **Activity & Profile Cards:** Background `#FFFFFF`, single `1px solid #E5E7EB` outline, `rounded-xl` border radius. Internal padding fixed at `space-lg` (`1.5rem`). No dropshadows.
- **Interactive Card Variant:** Includes an optional subtle state change where the border switches from `#E5E7EB` to `#FF5500` on tap or active participation.

### Chips & Tags
- **Filter & Interest Chips:** Height `36px` to `40px`, pill-shaped (`rounded-full`), `space-md` horizontal padding.
- **Unselected State:** `#FFFFFF` background, `1px solid #E5E7EB`, text `#4A4D52` (`label-md`).
- **Selected State:** `#FF5500` background, border `#FF5500`, text `#FFFFFF`.

### Form Controls & Inputs
- **Text Fields:** Height `52px`, `rounded-lg` (`1rem`), `#FFFFFF` background, `1px solid #E5E7EB` perimeter. Text in `#1E2022`, placeholder in `#4A4D52`. Focus ring transitions to a sharp `1.5px solid #FF5500` with no ambient glow.
- **Checkboxes & Radios:** `24px x 24px` hit area embedded within a minimum `48px` touch cell. Inactive state has `1.5px solid #E5E7EB` on white. Active state fills with `#FF5500` containing a crisp white tick or center dot.

### Lists & Activity Feeds
- **Traveller List Item:** Borderless rows separated by a `1px solid #E5E7EB` divider line. Left-aligned `48px` circular avatar, followed by headline name and activity chip. Right-aligned primary micro-action button ("Connect" / "Say Hi").
- **Zero Decorative Clutter Rule:** No background patterns, gradient washes, or ornamental icon badges are permitted within feed rows.

### Hostel-Specific UI
- **"Now in Common Room" Indicator:** A live status badge featuring an `8px` pulsating dot in `#FF5500`, housed in a pill chip (`#FAFAFA` background, `#E5E7EB` border, text `#1E2022`).
- **Meetup Match Bar:** Sticky bottom sheet with a bold `#FF5500` trigger button, optimized for quick thumb-reach across busy shared lounge spaces.